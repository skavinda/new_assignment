import java.util.Stack;

// RemoteControl Class
public class RemoteControl {
    private Command[] onCommands;
    private Command[] offCommands;
    private Command undoCommand;


    // Constructor initializes the command slots with no-op commands
    public RemoteControl() {
        onCommands = new Command[2];
        offCommands = new Command[2];
        undoCommand = null;

    }

    // Set commands for a particular slot

    public void setCommand(int slot, Command onCommand, Command offCommand) {
        onCommands[slot] = onCommand;
        offCommands[slot] = offCommand;
    }

    // Execute the 'on' command for a given slot
    public void onButtonPushed(int slot) {
        onCommands[slot].execute();
        undoCommand = onCommands[slot];

    }

    // Execute the 'off' command for a given slot
    public void offButtonPushed(int slot) {
        offCommands[slot].execute();
        undoCommand = offCommands[slot];

    }

    // Undo the last executed command
    public void undoButtonPushed() {
        if (undoCommand != null) {
            undoCommand.undo();
        }
    }
}