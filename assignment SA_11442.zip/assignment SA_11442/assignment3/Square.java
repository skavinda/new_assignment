public class Square implements Shape{

    int num=10;
    public void draw(){

        for (int i=1; i<=num; i++){
            for (int j=1; j<=num; j++) {
                System.out.print("* ");
            }
            System.out.println();
        }


    }
}
