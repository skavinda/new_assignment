public class Circle implements Shape{
    //radius
    int r=24/2;
    int diameter = 2 * r + 1;
    public void draw(){

        for (int i = 0; i < diameter; i++) {
            for (int j = 0; j < diameter; j++) {
                int x = i - r;
                int y = j - r;
                if (x * x + y * y <= r * r + r * 0.8) {
                    System.out.print("*  ");
                } else {
                    System.out.print("   ");
                }
            }
            System.out.println();
        }

    }
}
