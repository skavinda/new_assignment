public class ShapeFactory {
        public Shape getShape(String Shape) {
        if (Shape == null) {
            return null;
        }
        // Convert shapeType to uppercase to make the method case-insensitive
        switch (Shape.toUpperCase()) {
            case "CIRCLE":
                return new Circle();
            case "SQUARE":
                return new Square();
            case "TRIANGLE":
                return new Triangle();
            case "RECTANGLE":
                return new Rectangle();
            default:
                return null;
        }
    }
}
