public class Rectangle implements Shape {

    int num=20;
    int val=10;
    public void draw(){

        for (int i=1; i<=val; i++){
            for (int j=1; j<=num; j++) {
                System.out.print("* ");
            }
            System.out.println();
        }
    }
}
