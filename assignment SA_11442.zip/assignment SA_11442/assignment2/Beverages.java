abstract class Beverages {
    // Template method
    public final void finalTemplateMethod() {
        boilWater();
        brew();
        pourInCup();
        addCondiments();
        if (wantExtras) {
            addExtras();
        }
    }

    // Abstract methods
    abstract void brew();

    abstract void addCondiments();

    abstract void addExtras();

    // Concrete methods
    public void boilWater() {
        System.out.println("Boiling water");
    }

    public void pourInCup() {
        System.out.println("Pouring into cup");
    }

    // Field to determine
    boolean wantExtras = false;

    // Method to set wantsExtras
    public void setwantExtras(boolean wantsExtras) {
        this.wantExtras = wantsExtras;
    }

    public void setwantsExtras(boolean teaExtras) {
        this.wantExtras = wantExtras;
    }
}
